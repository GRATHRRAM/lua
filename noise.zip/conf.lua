function love.conf(t)
	t.title = "NOISE"
	t.window.width =  1200
	t.window.height = 720
end
