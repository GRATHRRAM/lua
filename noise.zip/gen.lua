gen = {}
local obj = {}

local x = 50
local y = 50

local scale = 10

function gen:update(dt)
    local cy = 0
    local cx = 0

    for i, v in ipairs(obj) do
        table.remove(obj,i)
   end

    while cy < y do
        cx = 0
        while cx < x do
            table.insert(obj,{y = cy,x = cx})
            cx = cx + 1
        end
        cy = cy + 1
    end
end


function gen:draw()
    for i, v in ipairs(obj) do
         love.graphics.setColor(math.random(10) / 10,math.random(10) / 10,math.random(10) / 10)
         love.graphics.rectangle("fill",obj[i].x * scale,obj[i].y * scale,scale,scale)  
    end
end

--table.insert(obj,{y = cy,x = cx,color = {r = math.random(10) / 10,g = math.random(10) / 10,b = math.random(10) / 10}})