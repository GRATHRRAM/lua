require("gen")

function love.load()
   
end

function love.update(dt)
    if love.keyboard.isDown("escape") then
        print(love.timer.getFPS())
        love.event.quit()
     end
     gen:update(dt)
end

function love.draw()
    gen:draw()
end

